#include "GridShift.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <sstream>
#include <thread>

static std::vector<std::string> split(const std::string& str, char delim) {
    std::vector<std::string> tokens;
    std::string token;
    for (char c : str) {
        if (c == delim) {
            tokens.push_back(token);
            token.clear();
        } else {
            token += c;
        }
    }
    tokens.push_back(token);
    return tokens;
}

GridShift::GridShift() 
    : playerX(0), playerY(0), score(0), targetValue(0), currentValue(0), 
      timer(60), initialTime(60), isZenMode(false), gameActive(false), isPaused(false) {
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
}

int GridShift::generateRandomNumber() const {
    // 70% chance 1-9, 30% chance 10-25
    if ((std::rand() % 100) < 70) {
        return (std::rand() % 9) + 1;
    } else {
        return (std::rand() % 16) + 10;
    }
}

void GridShift::newTarget() {
    int steps = 3 + score / 50;
    int tempValue = 0;
    for (int i = 0; i < steps; ++i) {
        int num = generateRandomNumber();
        tempValue += ((std::rand() % 2 == 0) ? num : -num);
    }
    // Clamping targets to reasonable bounds [20, 999]
    targetValue = std::max(20, std::min(999, tempValue));
    
    // Initial currentValue is set to a value somewhat close to target
    double ratio = 1.5 + (std::rand() % 100) / 200.0; // 1.5 to 2.0
    currentValue = static_cast<int>(targetValue / ratio);
}

void GridShift::initGame(int timeLimit) {
    score = 0;
    playerX = GRID_SIZE / 2;
    playerY = GRID_SIZE / 2;
    initialTime = timeLimit;
    timer = timeLimit;
    isZenMode = (timeLimit == -1);
    isPaused = false;

    // Fill grid
    for (int y = 0; y < GRID_SIZE; ++y) {
        for (int x = 0; x < GRID_SIZE; ++x) {
            grid[y][x] = generateRandomNumber();
        }
    }

    newTarget();
    gameActive = true;
    lastMoveTime = std::chrono::steady_clock::now();
}

void GridShift::updateTimer() {
    if (!gameActive || isPaused || isZenMode) return;

    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - lastMoveTime).count();
    
    if (elapsed > 0) {
        timer -= elapsed;
        lastMoveTime = now;
        if (timer <= 0) {
            timer = 0;
            gameActive = false;
        }
    }
}

void GridShift::render() const {
    // Clear console using ANSI escape codes
    std::cout << "\033[2J\033[1;1H";

    std::cout << "\033[1;36m==================================================\033[0m\n";
    std::cout << "\033[1;35m             🎮 GridSHIFT C++ Console 🎮\033[0m\n";
    std::cout << "\033[1;36m==================================================\033[0m\n";
    
    std::cout << " SCORE: \033[1;32m" << std::setw(4) << score << "\033[0m   |   TARGET: \033[1;32m" << std::setw(3) << targetValue 
              << "\033[0m   |   YOU: \033[1;31m" << std::setw(3) << currentValue << "\033[0m\n";
    
    std::cout << " TIME:  ";
    if (isZenMode) {
        std::cout << "\033[1;33m∞ (Zen Mode)\033[0m\n";
    } else {
        std::cout << "\033[1;33m" << timer << "s\033[0m\n";
    }
    std::cout << "\033[1;36m--------------------------------------------------\033[0m\n";

    for (int y = 0; y < GRID_SIZE; ++y) {
        std::cout << "  +----+----+----+----+----+----+----+----+\n  |";
        for (int x = 0; x < GRID_SIZE; ++x) {
            if (x == playerX && y == playerY) {
                // Highlight player position in Red color with brackets
                std::cout << "\033[1;31m[" << std::setw(2) << grid[y][x] << "]\033[0m|";
            } else {
                std::cout << " " << std::setw(2) << grid[y][x] << " |";
            }
        }
        std::cout << "\n";
    }
    std::cout << "  +----+----+----+----+----+----+----+----+\n";
    std::cout << "\033[1;36m--------------------------------------------------\033[0m\n";
    std::cout << " Controls: [w] Up | [s] Down | [a] Left (-Val) | [d] Right (+Val)\n";
    std::cout << " Commands: [p] Pause/Resume | [x] Save | [l] Load | [q] Quit\n";
    std::cout << "Enter command/move: ";
    std::cout.flush();
}

void GridShift::togglePause() {
    if (!gameActive) return;
    isPaused = !isPaused;
    if (!isPaused) {
        // Reset move timer on resume so player isn't penalized for pause duration
        lastMoveTime = std::chrono::steady_clock::now();
    }
}

void GridShift::processInput(char input) {
    if (!gameActive) return;

    // Handle pause toggle
    if (input == 'p' || input == 'P') {
        togglePause();
        return;
    }

    if (isPaused) return;

    // First update the timer based on thinking time
    updateTimer();
    if (!gameActive) return;

    int dx = 0;
    int dy = 0;

    switch (input) {
        case 'w': case 'W': dy = -1; break;
        case 's': case 'S': dy = 1; break;
        case 'a': case 'A': dx = -1; break;
        case 'd': case 'D': dx = 1; break;
        case 'x': case 'X':
            if (saveGame()) {
                std::cout << "\033[1;32mGame Saved successfully to savegame.txt!\033[0m\n";
            } else {
                std::cout << "\033[1;31mFailed to save game.\033[0m\n";
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            return;
        case 'l': case 'L':
            if (loadGame()) {
                std::cout << "\033[1;32mGame Loaded successfully!\033[0m\n";
            } else {
                std::cout << "\033[1;31mFailed to load game.\033[0m\n";
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            return;
        case 'q': case 'Q':
            gameActive = false;
            return;
        default:
            return; // Ignore invalid keys
    }

    int newX = playerX + dx;
    int newY = playerY + dy;

    if (newX >= 0 && newX < GRID_SIZE && newY >= 0 && newY < GRID_SIZE) {
        playerX = newX;
        playerY = newY;

        int tileVal = grid[playerY][playerX];
        if (dx == 1) { // Moving Right -> ADD
            currentValue += tileVal;
            grid[playerY][playerX] = generateRandomNumber();
        } else if (dx == -1) { // Moving Left -> SUBTRACT
            currentValue -= tileVal;
            grid[playerY][playerX] = generateRandomNumber();
        }

        // Check win condition
        if (currentValue == targetValue) {
            score += 10;
            if (!isZenMode) {
                timer += 10; // +10 sec bonus
            }
            newTarget();
        }
    }
}

bool GridShift::saveGame(const std::string& filepath) const {
    std::ofstream file(filepath);
    if (!file.is_open()) return false;

    file << playerX << "|" << playerY << "\n";
    file << score << "|" << targetValue << "|" << currentValue << "|" 
         << timer << "|" << initialTime << "|" << (isZenMode ? 1 : 0) << "|" << (gameActive ? 1 : 0) << "\n";

    for (int y = 0; y < GRID_SIZE; ++y) {
        for (int x = 0; x < GRID_SIZE; ++x) {
            file << grid[y][x];
            if (x < GRID_SIZE - 1) file << ",";
        }
        file << "\n";
    }

    file.close();
    return true;
}

bool GridShift::loadGame(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) return false;

    std::string line;
    // Read player pos
    if (!std::getline(file, line)) return false;
    auto parts = split(line, '|');
    if (parts.size() < 2) return false;
    playerX = std::stoi(parts[0]);
    playerY = std::stoi(parts[1]);

    // Read metrics
    if (!std::getline(file, line)) return false;
    parts = split(line, '|');
    if (parts.size() < 7) return false;
    score = std::stoi(parts[0]);
    targetValue = std::stoi(parts[1]);
    currentValue = std::stoi(parts[2]);
    timer = std::stoi(parts[3]);
    initialTime = std::stoi(parts[4]);
    isZenMode = (std::stoi(parts[5]) != 0);
    gameActive = (std::stoi(parts[6]) != 0);

    // Read grid
    for (int y = 0; y < GRID_SIZE; ++y) {
        if (!std::getline(file, line)) return false;
        auto cells = split(line, ',');
        if (cells.size() < static_cast<size_t>(GRID_SIZE)) return false;
        for (int x = 0; x < GRID_SIZE; ++x) {
            grid[y][x] = std::stoi(cells[x]);
        }
    }

    file.close();
    // Reset move clock to now to prevent immediate time penalty
    lastMoveTime = std::chrono::steady_clock::now();
    isPaused = false;
    return true;
}

std::string GridShift::cleanName(const std::string& name) const {
    std::string cleaned;
    for (char c : name) {
        if (c != '|' && c != '\n' && c != '\r') {
            cleaned += c;
        }
    }
    if (cleaned.empty()) cleaned = "Player";
    return cleaned;
}

bool GridShift::saveHighScore(const std::string& name, const std::string& filepath) const {
    std::ofstream file(filepath, std::ios::app);
    if (!file.is_open()) return false;

    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);
    struct tm* timeinfo = std::localtime(&in_time_t);
    char buffer[80];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M", timeinfo);

    file << cleanName(name) << "|" << score << "|" << buffer << "\n";
    file.close();
    return true;
}

void GridShift::displayHighScores(const std::string& filepath) const {
    std::ifstream file(filepath);
    std::vector<HighScore> list;
    std::string line;

    if (file.is_open()) {
        while (std::getline(file, line)) {
            if (line.empty()) continue;
            auto parts = split(line, '|');
            if (parts.size() < 3) continue;
            HighScore hs;
            hs.name = parts[0];
            hs.score = std::stoi(parts[1]);
            hs.date = parts[2];
            list.push_back(hs);
        }
        file.close();
    }

    // Sort highscores using Selection Sort (descending)
    size_t len = list.size();
    for (size_t i = 0; i < len - 1; ++i) {
        size_t max_idx = i;
        for (size_t j = i + 1; j < len; ++j) {
            if (list[j].score > list[max_idx].score) {
                max_idx = j;
            }
        }
        if (max_idx != i) {
            std::swap(list[i], list[max_idx]);
        }
    }

    std::cout << "\n\033[1;33m--------------------------------------------------\033[0m\n";
    std::cout << "\033[1;35m               🏆 LEADERBOARD 🏆                  \033[0m\n";
    std::cout << "\033[1;33m--------------------------------------------------\033[0m\n";
    std::cout << std::left << std::setw(6) << "Rank" << std::setw(15) << "Player" << std::setw(10) << "Score" << std::setw(15) << "Date" << "\n";
    std::cout << "--------------------------------------------------\n";
    
    size_t displayCount = std::min(list.size(), static_cast<size_t>(10));
    if (displayCount == 0) {
        std::cout << "        (No highscores yet. Be the first!)\n";
    } else {
        for (size_t i = 0; i < displayCount; ++i) {
            std::cout << std::left << std::setw(6) << (i + 1)
                      << std::setw(15) << list[i].name
                      << std::setw(10) << list[i].score
                      << std::setw(15) << list[i].date << "\n";
        }
    }
    std::cout << "\033[1;33m--------------------------------------------------\033[0m\n";
}
