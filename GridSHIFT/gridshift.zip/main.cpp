#include "GridShift.h"
#include <iostream>
#include <string>
#include <limits>
#include <thread>

void showWelcome() {
    std::cout << "\n\033[1;36m==================================================\033[0m\n";
    std::cout << "\033[1;35m             ✨ WELCOME TO GridSHIFT! ✨\033[0m\n";
    std::cout << "\033[1;36m==================================================\033[0m\n";
    std::cout << " Land on a number from the left or right to perform\n"
              << " calculations: \n"
              << "   - Moving \033[1;31mLEFT\033[0m into a tile \033[1;31mSUBTRACTS\033[0m its value.\n"
              << "   - Moving \033[1;32mRIGHT\033[0m into a tile \033[1;32mADDS\033[0m its value.\n"
              << "   - Moving \033[1;33mUP/DOWN\033[0m has \033[1;33mNO math effect\033[0m (repositioning).\n\n"
              << " Match the \033[1;32mTARGET\033[0m to score 10 pts and get +10s time!\n";
    std::cout << "\033[1;36m==================================================\033[0m\n";
}

void playGame(GridShift& game, int timeLimit, bool resume = false) {
    if (!resume) {
        game.initGame(timeLimit);
    }

    while (!game.isGameOver()) {
        if (game.getIsPaused()) {
            std::cout << "\033[2J\033[1;1H";
            std::cout << "\n\033[1;33m=== GAME PAUSED ===\033[0m\n";
            std::cout << "Press [p + Enter] to Resume.\n";
            std::cout << "Enter command: ";
            std::cout.flush();
        } else {
            game.render();
        }

        std::string inputStr;
        if (!(std::cin >> inputStr)) {
            if (std::cin.eof()) {
                std::cout << "\nInput stream ended. Exiting game.\n";
                break;
            }
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }

        if (inputStr.length() == 1) {
            game.processInput(inputStr[0]);
        } else {
            // Process chain of moves sequentially
            for (char cmd : inputStr) {
                game.processInput(cmd);
                if (game.isGameOver() || game.getIsPaused()) break;
            }
        }
    }

    std::cout << "\033[2J\033[1;1H";
    std::cout << "\n\033[1;31m==================================================\033[0m\n";
    std::cout << "\033[1;31m                   GAME OVER!                     \033[0m\n";
    std::cout << "\033[1;31m==================================================\033[0m\n";
    std::cout << " Your final score: \033[1;32m" << game.getScore() << "\033[0m points\n";

    if (game.getScore() > 0) {
        std::cout << "\nEnter your name to record in High Scores: ";
        std::string name;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::getline(std::cin, name);
        if (std::cin.eof()) return;
        
        if (name.empty()) name = "Player";
        game.saveHighScore(name);
        std::cout << "\033[1;32mHigh score recorded!\033[0m\n";
    }

    game.displayHighScores();
    std::cout << "\nPress Enter to return to main menu...";
    std::cin.get();
}

int main() {
    GridShift game;
    int choice = 0;

    while (choice != 4) {
        std::cout << "\033[2J\033[1;1H";
        showWelcome();
        std::cout << "  \033[1;32m1.\033[0m Start New Game\n";
        std::cout << "  \033[1;32m2.\033[0m Load Saved Game (savegame.txt)\n";
        std::cout << "  \033[1;32m3.\033[0m View High Score Leaderboard\n";
        std::cout << "  \033[1;31m4. Exit\033[0m\n";
        std::cout << "\033[1;36m==================================================\033[0m\n";
        std::cout << "Enter your choice (1-4): ";

        if (!(std::cin >> choice)) {
            if (std::cin.eof()) {
                break;
            }
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }

        switch (choice) {
            case 1: {
                std::cout << "\nSelect Game Mode:\n";
                std::cout << "  1. 30 Seconds (Fast Pace)\n";
                std::cout << "  2. 60 Seconds (Standard)\n";
                std::cout << "  3. 90 Seconds (Extended)\n";
                std::cout << "  4. Zen Mode (No Time Limit)\n";
                std::cout << "Enter mode (1-4): ";
                int mode;
                if (!(std::cin >> mode) || mode < 1 || mode > 4) {
                    if (std::cin.eof()) return 0;
                    std::cin.clear();
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                    std::cout << "Invalid mode. Defaulting to 60s.\n";
                    mode = 2;
                }
                int timeLimit = 60;
                if (mode == 1) timeLimit = 30;
                else if (mode == 3) timeLimit = 90;
                else if (mode == 4) timeLimit = -1;

                playGame(game, timeLimit, false);
                break;
            }
            case 2:
                if (game.loadGame("savegame.txt")) {
                    std::cout << "\033[1;32mSuccessfully loaded saved game state!\033[0m\n";
                    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
                    playGame(game, 0, true);
                } else {
                    std::cout << "\033[1;31mError: savegame.txt not found or corrupt.\033[0m\n";
                    std::this_thread::sleep_for(std::chrono::milliseconds(1500));
                }
                break;
            case 3:
                std::cout << "\033[2J\033[1;1H";
                game.displayHighScores();
                std::cout << "\nPress Enter to return to main menu...";
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cin.get();
                break;
            case 4:
                std::cout << "\nThank you for playing GridSHIFT! Goodbye.\n";
                break;
            default:
                break;
        }
    }

    return 0;
}
