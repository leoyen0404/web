#ifndef GRIDSHIFT_H
#define GRIDSHIFT_H

#include <string>
#include <vector>
#include <chrono>

struct HighScore {
    std::string name;
    int score;
    std::string date;
};

class GridShift {
private:
    static const int GRID_SIZE = 8;
    int grid[GRID_SIZE][GRID_SIZE];
    int playerX;
    int playerY;
    int score;
    int targetValue;
    int currentValue;
    int timer; // in seconds
    int initialTime;
    bool isZenMode;
    bool gameActive;
    bool isPaused;

    std::chrono::steady_clock::time_point lastMoveTime;

    int generateRandomNumber() const;
    void newTarget();
    void updateTimer();
    std::string cleanName(const std::string& name) const;
public:
    GridShift();
    ~GridShift() = default;

    void initGame(int timeLimit);
    void render() const;
    void processInput(char input);
    bool isGameOver() const { return !gameActive; }
    int getScore() const { return score; }

    bool saveGame(const std::string& filepath = "savegame.txt") const;
    bool loadGame(const std::string& filepath = "savegame.txt");
    bool saveHighScore(const std::string& name, const std::string& filepath = "highscores.txt") const;
    void displayHighScores(const std::string& filepath = "highscores.txt") const;
    void togglePause();
    bool getIsPaused() const { return isPaused; }
};

#endif
