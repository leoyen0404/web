# GridSHIFT C++ Console Game

## 專案簡介 (Project Introduction)
`GridSHIFT` 是一個從 HTML/JS 移植的終端機數學拼圖遊戲。玩家在一個 $8 \times 8$ 的數字矩陣中移動，目標是透過方向性的數學運算，使目前數值（currentValue）精確匹配隨機產生的目標數值（targetValue）。本專案完全以標準 C++ 實作，無任何第三方套件依賴，並支援存讀檔與排行榜等檔案操作。

### 核心運算規則
* ➡️ **向右移動 (`d`)**：將目標格子的數值**加**到目前數值。
* ⬅️ **向左移動 (`a`)**：將目標格子的數值**減**去目前數值。
* ⬆️ / ⬇️ **向上 (`w`) / 向下 (`s`) 移動**：純粹改變位置，**不進行任何數學運算**（可用於繞路與重新布局）。

---

## 系統架構與類別設計 (Object-Oriented Design)
專案遵循物件導向設計原則，實作模組封裝：

### 1. `GridShift` 類別
負責管理遊戲狀態、地圖陣列、玩家座標、分數、目標值與時間計算。
* **資料結構**：使用二維陣列 `int grid[8][8]` 儲存盤面數字。
* **時序計算**：採用 `std::chrono::steady_clock` 實現非阻塞式時間扣減。
* **序列化**：實作 `saveGame` 與 `loadGame` 將當前進度以 `|` 與 `,` 分割符寫入 `savegame.txt`。

### 2. `HighScore` 結構體
儲存玩家排行榜紀錄：
* `std::string name` (姓名)
* `int score` (分數)
* `std::string date` (日期，採用 `%Y-%m-%d %H:%M` 格式)

### 3. 主程式控制 (`main.cpp`)
處理主選單循環、關卡難度設定（30秒、60秒、90秒、禪宗無限制模式）以及分數結算與姓名登錄。

---

## 檔案操作與儲存設計 (File Operations)
本專案不使用任何數據庫，完全採用標準檔案串流（C++ Standard File I/O）實現：
* **存檔與讀檔 (`savegame.txt`)**：序列化儲存玩家座標、分數、目標值、目前值、剩餘時間、禪宗模式狀態以及整個地圖陣列。
* **排行榜 (`highscores.txt`)**：採用 Append 模式記錄每局成績。讀取時透過手寫的 **選擇排序法 (Selection Sort)** 進行降序排序，並輸出前 10 名。

---

## 編譯與執行說明 (Compilation & Execution)
請確保您已安裝 C++11 (或更新版本) 的編譯器：

### macOS / Linux
```bash
clang++ -std=c++11 -Wall -Wextra main.cpp GridShift.cpp -o gridshift
./gridshift
```

### Windows (cmd / Powershell)
使用 MinGW `g++` 編譯：
```cmd
g++ -std=c++11 -Wall -Wextra main.cpp GridShift.cpp -o gridshift.exe
gridshift.exe
```

---

## 進階特色功能 (Feature Highlights)
1. **動態鏈結移動 (Command Chaining)**：玩家可以在輸入框中一次輸入多個方向鍵（例如輸入 `ddws` 後按 Enter），主程式會自動拆解並依序執行「右、右、上、下」，大幅提升計算的流暢度。
2. **防作弊計時器**：為了解決控制台 `std::cin` 阻塞的問題，系統會計算前後兩次移動的真實時間差（Elapsed time），在玩家移動的瞬間扣除秒數。同時，在暫停（Pause）期間會凍結時間差，保障計時的精準公平。
3. **ANSI 彩色渲染**：使用標準 ANSI 控制碼渲染動態彩色的邊框與玩家座標（紅字中括號標示 `[ x ]`），提供流暢且清晰的視覺反饋。
